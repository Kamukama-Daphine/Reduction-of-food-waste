package ug.global.savor.adapters;

import android.content.Context;
import android.os.Build;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import ug.global.savor.R;
import ug.global.savor.objects.ForumChat;

public class ForumChatAdapter extends RecyclerView.Adapter<ForumChatAdapter.ViewHolder> {
    private ArrayList<ForumChat> forumChats;
    private Context context;

    public ForumChatAdapter(ArrayList<ForumChat> forumChats, Context context) {
        this.forumChats = forumChats;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.message_item, parent, false));
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ForumChat forumChat = forumChats.get(position);
        if (forumChat.getSender().equals(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getDisplayName())) {
            holder.sender.setText(R.string.you);
            holder.sender.setTextColor(context.getColor(R.color.colorBlue));
        } else {
            holder.sender.setText(forumChat.getSender());
        }
        String timepast = DateUtils.getRelativeTimeSpanString(forumChat.getDate(), System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString();
        Glide.with(context).load(forumChat.getPhoto()).into(holder.imageView);
        holder.date.setText(timepast);
        holder.message.setText(forumChat.getMessage());
    }

    @Override
    public int getItemCount() {
        return forumChats.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imageView;
        TextView date, message, sender;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.avatar);
            date = itemView.findViewById(R.id.time);
            message = itemView.findViewById(R.id.message);
            sender = itemView.findViewById(R.id.sender);
        }
    }
}
