package ug.global.savor.objects;

import java.util.ArrayList;

public class UserObject {
    private String firebaseUser;
    private ArrayList<String> giveAways;
    private boolean giver;
    private boolean show;
    private String name;
    private String photo;
    private long shares;

    public UserObject() {}

    public UserObject(String firebaseUser, ArrayList<String> giveAways, boolean giver, String name, String photo) {
        this.firebaseUser = firebaseUser;
        this.giveAways = giveAways;
        this.giver = giver;
        this.name = name;
        this.photo = photo;
        this.show = false;
        this.shares = 0;
    }

    public boolean isShow() {
        return show;
    }

    public String getName() {
        return name;
    }

    public String getPhoto() {
        return photo;
    }

    public long getShares() {
        return shares;
    }

    public String getFirebaseUser() {
        return firebaseUser;
    }

    public ArrayList<String> getGiveAways() {
        return giveAways;
    }

    public boolean isGiver() {
        return giver;
    }
}
