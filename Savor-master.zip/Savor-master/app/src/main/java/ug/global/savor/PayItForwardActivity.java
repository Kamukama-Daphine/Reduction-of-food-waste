package ug.global.savor;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;

import java.util.Objects;

import ug.global.savor.objects.Donation;

public class PayItForwardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_it_forward);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.pay);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        final RadioGroup radioGroup = findViewById(R.id.radioGroup);
        final MaterialButton button = findViewById(R.id.sponsor);
        final CheckBox checkBox = findViewById(R.id.checkBox);
        final TextInputEditText phone = findViewById(R.id.number);
        final TextInputEditText amount = findViewById(R.id.amount);
        phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                amount.setEnabled(phone.getEditableText().toString().trim().length() >= 10);
            }
        });
        amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                checkBox.setEnabled(amount.getEditableText().toString().trim().length() > 3);
                button.setEnabled(amount.getEditableText().toString().trim().length() > 3);
            }
        });
        final View main = findViewById(R.id.main);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button.setEnabled(false);
                String number = phone.getEditableText().toString().trim();
                final String amountTxt = amount.getEditableText().toString().trim();
                final Boolean showInWallOfFame = checkBox.isChecked();
                final String type = ((RadioButton) radioGroup.findViewById(radioGroup.getCheckedRadioButtonId())).getText().toString();
                button.setText(R.string.PROCESSING);
                final FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        AlertDialog alertDialog = new MaterialAlertDialogBuilder(PayItForwardActivity.this).create();
                        @SuppressLint("InflateParams") View view = getLayoutInflater().inflate(R.layout.mobile_number_alert, null, false);
                        alertDialog.setView(view);
                        final TextInputEditText number = view.findViewById(R.id.number);
                        TextView title = view.findViewById(R.id.title);
                        title.setText(String.format("Merchant SAVOR UG. Has initiated a trancation of Ugx.%s. Please enter your PIN to confirm", amountTxt));
                        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "SEND", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String pin = number.getEditableText().toString().trim();
                                if (pin.equals("1234")) {
                                    final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("/users/" + currentUser.getUid());
                                    if (showInWallOfFame) {
                                        reference.child("show").setValue(true);
                                    }
                                    reference.child("shares").runTransaction(new Transaction.Handler() {
                                        @NonNull
                                        @Override
                                        public Transaction.Result doTransaction(@NonNull MutableData mutableData) {
                                            Log.i("", "doTransaction: " + reference.child("shares"));
                                            Long value = mutableData.getValue(Long.class);
                                            mutableData.setValue(value + 1);
                                            return Transaction.success(mutableData);
                                        }

                                        @Override
                                        public void onComplete(@Nullable DatabaseError databaseError, boolean b, @Nullable DataSnapshot dataSnapshot) {
                                            Log.d("TAG", "transaction:onComplete:" + databaseError);
                                        }
                                    });
                                    Snackbar.make(main, "Payment Received. Thank you", BaseTransientBottomBar.LENGTH_LONG).show();
                                    Donation donation = new Donation(currentUser.getUid(), amountTxt, type);
                                    final DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference("/donations");
                                    reference1.child(Objects.requireNonNull(reference1.push().getKey())).setValue(donation);


                                } else {
                                    Snackbar.make(main, "Incorrect Pin. Please try again", BaseTransientBottomBar.LENGTH_LONG).show();
                                }

                            }
                        });
                        alertDialog.setCancelable(false);
                        alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "CANCEL", new DialogInterface.OnClickListener() {
                            @SuppressLint("SetTextI18n")
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                button.setText("Sponsor");
                                button.setEnabled(true);
                            }
                        });
                        alertDialog.show();
                    }
                }, 5000);
            }
        });


    }
}