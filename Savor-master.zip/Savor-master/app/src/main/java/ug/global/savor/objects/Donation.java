package ug.global.savor.objects;

public class Donation {
    String user;
    String amount;
    String type;

    public Donation(String user, String amount, String type) {
        this.user = user;
        this.amount = amount;
        this.type = type;
    }

    public String getUser() {
        return user;
    }

    public String getAmount() {
        return amount;
    }

    public String getType() {
        return type;
    }
}
