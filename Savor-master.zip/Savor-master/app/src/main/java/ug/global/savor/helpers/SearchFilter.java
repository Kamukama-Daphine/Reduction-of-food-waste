package ug.global.savor.helpers;

import android.widget.Filter;

import java.util.ArrayList;

import ug.global.savor.adapters.FoodItemsAdapter;
import ug.global.savor.objects.ListingObject;


public class SearchFilter extends Filter {
    private FoodItemsAdapter adapter;
    private ArrayList<ListingObject> filterList;

    public SearchFilter(ArrayList<ListingObject> filterList, FoodItemsAdapter adapter) {
        this.adapter = adapter;
        this.filterList = filterList;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();

        //CHECK CONSTRAINT VALIDITY
        if (constraint != null && constraint.length() > 0) {
            //CHANGE TO UPPER
            constraint = constraint.toString();
            ArrayList<ListingObject> filteredProducts = new ArrayList<>();
            //STORE OUR FILTERED DRINKS
            if (constraint.equals("food")) {
                for (ListingObject listingObject : filterList) {
                    if (listingObject.isFood()) {
                        filteredProducts.add(listingObject);
                    }
                }
            } else if (constraint.equals("drink")) {
                for (ListingObject listingObject : filterList) {
                    if (!listingObject.isFood()) {
                        filteredProducts.add(listingObject);
                    }
                }
            } else {
                filteredProducts.addAll(filterList);
            }
            results.count = filteredProducts.size();
            results.values = filteredProducts;
        } else {
            results.count = filterList.size();
            results.values = filterList;

        }

        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {

        adapter.listingObjects = (ArrayList<ListingObject>) results.values;
        adapter.notifyDataSetChanged();
    }

}
