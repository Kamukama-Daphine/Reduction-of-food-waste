package ug.global.savor;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PointOfInterest;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

import ug.global.savor.adapters.FoodItemsAdapter;
import ug.global.savor.helpers.Helpers;
import ug.global.savor.objects.ListingObject;

public class AddListingActivity extends AppCompatActivity {
    private static final int MAP_REQUEST_CODE = 12111;
    Button time;
    private Uri imageUri;
    private ImageView getCameraImage;
    private boolean isFood = true;
    private TextInputEditText title, description;
    private TextView locationTxt;
    private String pickupLocation = "";
    private ProgressDialog progressDialog;
    private View mainView;
    private TextView daysText;
    private long days = 5;
    private boolean editMode = false;
    private String titleTxt;
    private Task<Uri> mainTast;
    private String descTxt;

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_listing);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        ChipGroup chipGroup = findViewById(R.id.chipGroup);
        mainView = findViewById(R.id.mainView);
        locationTxt = findViewById(R.id.locationTxt);
        getCameraImage = findViewById(R.id.cameraImage);
        title = findViewById(R.id.titleText);
        description = findViewById(R.id.description);
        daysText = findViewById(R.id.timeText);
        time = findViewById(R.id.timeLayout);

        if (getIntent().getBooleanExtra("edit_mode", false)) {
            editMode = true;
            title.setText(FoodItemsAdapter.activeObject.getName());
            description.setText(FoodItemsAdapter.activeObject.getDescription());
            daysText.setText(String.format("Show for %d days", FoodItemsAdapter.activeObject.getDaysToList()));
            time.setText(FoodItemsAdapter.activeObject.getPickupTime());
            Glide.with(this).load(FoodItemsAdapter.activeObject.getPhoto()).into(getCameraImage);
        }
        daysText.setText(String.format("List for %d days", days));
        ImageView addDays = findViewById(R.id.addImage), removeDays = findViewById(R.id.removeImage);
        addDays.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (days < 5) {
                    days++;
                    daysText.setText(String.format("List for %d days", days));
                }
            }
        });
        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        int minute = mcurrentTime.get(Calendar.MINUTE);
        final TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                String strHour = String.valueOf(selectedHour), strMin = String.valueOf(selectedMinute), strAM_PM;
                // if(strHour.length()==1) strHour="0" + strHour;
                if (strMin.length() == 1) strMin = "0" + strMin;

                if (selectedHour == 0) {
                    selectedHour += 12;
                    strAM_PM = "AM";
                } else if (selectedHour == 12) {
                    strAM_PM = "PM";
                } else if (selectedHour > 12) {
                    selectedHour = selectedHour - 12;
                    strAM_PM = "PM";
                } else {
                    strAM_PM = "AM";
                }
                findViewById(R.id.saveButton).setEnabled(true);
                time.setText(selectedHour + ":" + strMin + " " + strAM_PM);

            }
        }, hour, minute, true);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mTimePicker.show();
            }
        });
        removeDays.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (days > 1) {
                    days--;
                    daysText.setText(String.format("List for %d days", days));
                }
            }
        });
        chipGroup.setOnCheckedChangeListener(new ChipGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(ChipGroup group, int checkedId) {
                isFood = checkedId == R.id.food;
            }
        });
        if (ActivityCompat.checkSelfPermission(AddListingActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(AddListingActivity.this
                , Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 111);
            return;
        }
        if (ActivityCompat.checkSelfPermission(AddListingActivity.this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(AddListingActivity.this
                , Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH}, 111);
            return;
        }
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Saving");
        progressDialog.setMessage("Please wait");
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(5 * 1000);
        LocationCallback locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                for (Location location : locationResult.getLocations()) {
                    pickupLocation = location.getLatitude() + "__" + location.getLongitude();
                    new Helpers().convertLocation(locationTxt, AddListingActivity.this, location.getLongitude(), location.getLatitude());

                }
            }

        };
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        findViewById(R.id.pickLocation).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(AddListingActivity.this, MapsActivity.class), MAP_REQUEST_CODE);
            }
        });
        final String user = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
        findViewById(R.id.saveButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titleTxt = title.getEditableText().toString().trim();
                descTxt = description.getEditableText().toString().trim();
                final String timeTxt = time.getText().toString();
                if (pickupLocation.equals("")) {
                    Snackbar.make(mainView, "Please choose a location", BaseTransientBottomBar.LENGTH_LONG).show();
                } else if (titleTxt.equals("") || descTxt.equals("") || timeTxt.equals("")) {

                    Snackbar.make(mainView, "All fields a required to save a listing", BaseTransientBottomBar.LENGTH_LONG).show();
                } else if (imageUri == null && !editMode) {

                    Snackbar.make(mainView, "You need to upload a photo to continue", BaseTransientBottomBar.LENGTH_LONG).show();
                } else {
                    final ProgressDialog progressDialog = new ProgressDialog(AddListingActivity.this);
                    progressDialog.setTitle("Saving Item");
                    progressDialog.setMessage("Please wait while we upload the data");
                    progressDialog.setCanceledOnTouchOutside(false);
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    if (editMode && imageUri == null) {
                        ListingObject listingObject = FoodItemsAdapter.activeObject;
                        listingObject.setName(titleTxt);
                        listingObject.setDescription(descTxt);
                        listingObject.setDaysToList(days);
                        listingObject.setPickupLocation(pickupLocation);
                        listingObject.setPickupTime(timeTxt);
                        saveData(listingObject.getKey(), listingObject);
                    } else {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReference("photos");
                        final StorageReference rivers_ref = storageReference.child(Objects.requireNonNull(imageUri.getLastPathSegment()));
                        UploadTask uploadTask = rivers_ref.putFile(imageUri);
                        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                            @Override
                            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                if (!task.isSuccessful()) {
                                    throw Objects.requireNonNull(task.getException());
                                }
                                return rivers_ref.getDownloadUrl();
                            }
                        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                mainTast = task;
                                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("/listings");
                                ListingObject listingObject = new ListingObject(titleTxt, Objects.requireNonNull(mainTast.getResult()).toString(), isFood, descTxt, days, user, false,
                                        Calendar.getInstance().getTimeInMillis(), timeTxt, pickupLocation);
                                saveData(editMode ? FoodItemsAdapter.activeObject.getKey() : reference.push().getKey(), listingObject);
                            }
                        });
                    }
                }
            }

            private void saveData(String key, ListingObject listingObject) {
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("/listings");
                reference.child(key != null ? key : Calendar.getInstance().getTimeInMillis() + user).setValue(listingObject);
                reference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        progressDialog.dismiss();
                        finish();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Snackbar.make(mainView, "An error occurred. Please try again later", BaseTransientBottomBar.LENGTH_LONG).show();
                        progressDialog.dismiss();
                        finish();
                    }
                });
            }
        });
        getCameraImage.setOnClickListener(new View.OnClickListener() {
            private static final int MY_CAMERA_PERMISSION_CODE = 121;

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
                }
                CropImage.activity(imageUri).setGuidelines(CropImageView.Guidelines.ON).setAspectRatio(3, 2).start(AddListingActivity.this);
            }
        });
    }


    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();
                getCameraImage.setImageURI(resultUri);
                imageUri = resultUri;
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                    MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, new Date().toString(), "Savor photos");
                    Log.d("sijihdb", CapturePhotoUtils.insertImage(getContentResolver(), bitmap, new Date().toString(), "Savor photos"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else if (requestCode == MAP_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                assert data != null;
                final PointOfInterest pointOfInterest = (PointOfInterest) Objects.requireNonNull(data.getExtras()).get("location");
                assert pointOfInterest != null;
                progressDialog.show();
                LatLng latLng = pointOfInterest.latLng;
                Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
                android.location.Address address;
                try {
                    address = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1).get(0);
                    locationTxt.setText(address.getAddressLine(0));
                    pickupLocation = latLng.latitude + "__" + latLng.longitude;
                } catch (IOException e) {
                    progressDialog.dismiss();
                    Snackbar.make(findViewById(R.id.main), "It looks like the geocode service is not available. Please reboot you device", Snackbar.LENGTH_LONG).show();
                }
            }
        }

    }

    public static class CapturePhotoUtils {
        @RequiresApi(api = Build.VERSION_CODES.Q)
        public static String insertImage(ContentResolver cr, Bitmap source, String title, String description) {
            Log.d("Ohoto interted", "skjbddf");
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.TITLE, title);
            values.put(MediaStore.Images.Media.DISPLAY_NAME, title);
            values.put(MediaStore.Images.Media.DESCRIPTION, description);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis());
            values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());

            Uri url = null;
            String stringUrl = null;    /* value to be returned */

            try {
                url = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

                if (source != null) {
                    try (OutputStream imageOut = cr.openOutputStream(url)) {
                        source.compress(Bitmap.CompressFormat.JPEG, 50, imageOut);
                    }

                    long id = ContentUris.parseId(url);
                    // Wait until MINI_KIND thumbnail is generated.
                    Bitmap miniThumb = MediaStore.Images.Thumbnails.getThumbnail(cr, id, MediaStore.Images.Thumbnails.MINI_KIND, null);
                    // This is for backward compatibility.
                    storeThumbnail(cr, miniThumb, id);
                } else {
                    cr.delete(url, null, null);
                    url = null;
                }
            } catch (Exception e) {
                if (url != null) {
                    cr.delete(url, null, null);
                    url = null;
                }
            }

            if (url != null) {
                stringUrl = url.toString();
            }

            return stringUrl;
        }

        private static void storeThumbnail(ContentResolver cr, Bitmap source, long id) {

            // create the matrix to scale it
            Matrix matrix = new Matrix();

            float scaleX = (float) 50.0 / source.getWidth();
            float scaleY = (float) 50.0 / source.getHeight();

            matrix.setScale(scaleX, scaleY);

            Bitmap thumb = Bitmap.createBitmap(source, 0, 0,
                    source.getWidth(),
                    source.getHeight(), matrix,
                    true
            );

            ContentValues values = new ContentValues(4);
            values.put(MediaStore.Images.Thumbnails.KIND, MediaStore.Images.Thumbnails.MICRO_KIND);
            values.put(MediaStore.Images.Thumbnails.IMAGE_ID, (int) id);
            values.put(MediaStore.Images.Thumbnails.HEIGHT, thumb.getHeight());
            values.put(MediaStore.Images.Thumbnails.WIDTH, thumb.getWidth());

            Uri url = cr.insert(MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, values);

            try {
                OutputStream thumbOut = cr.openOutputStream(url);
                thumb.compress(Bitmap.CompressFormat.JPEG, 100, thumbOut);
                thumbOut.close();
            } catch (IOException ignored) {
            }
        }
    }
}
