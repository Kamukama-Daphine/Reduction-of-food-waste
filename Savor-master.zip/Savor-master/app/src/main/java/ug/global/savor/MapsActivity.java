package ug.global.savor;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PointOfInterest;
import com.google.android.material.snackbar.Snackbar;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final int MAP_PIN_LOCATION_REQUEST_CODE = 2232;
    private ProgressDialog progressDialog;
    private double longitude;
    private double latitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Loading Location");
        progressDialog.setMessage("Please wait while we load your current location");
        if (progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        progressDialog.show();

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        final SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MAP_PIN_LOCATION_REQUEST_CODE);
                recreate();
                return;
            }
        }

        final LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;

        try {
            assert lm != null;
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) { ex.printStackTrace();}
        try {network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);} catch (Exception ex) { ex.printStackTrace();}
        if (gps_enabled)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                public void onLocationChanged(Location location) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    lm.removeUpdates(this);
                    mapFragment.getMapAsync(MapsActivity.this);
                }

                public void onProviderDisabled(String provider) {}

                public void onProviderEnabled(String provider) {}

                public void onStatusChanged(String provider, int status, Bundle extras) {}
            });
        if (network_enabled)
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener() {
                public void onLocationChanged(Location location) {

                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    lm.removeUpdates(this);
                    mapFragment.getMapAsync(MapsActivity.this);
                }

                public void onProviderDisabled(String provider) {}

                public void onProviderEnabled(String provider) {}

                public void onStatusChanged(String provider, int status, Bundle extras) {}
            });


        Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (location == null) {
            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 200, 10, new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {

                        longitude = location.getLongitude();
                        latitude = location.getLatitude();
                        progressDialog.hide();
                    }

                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {

                    }

                    @Override
                    public void onProviderEnabled(String provider) {

                    }

                    @Override
                    public void onProviderDisabled(String provider) {

                    }
                });
            } catch (IllegalArgumentException e) {
                Toast.makeText(this, "GPS Not available. Location results might not be accurate", Toast.LENGTH_SHORT).show();
            }
        } else {
            longitude = location.getLongitude();
            latitude = location.getLatitude();
            progressDialog.hide();
            progressDialog.dismiss();


        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        if (getIntent().getBooleanExtra("show_listing", false)) {
            LatLng current_location = new LatLng(getIntent().getDoubleExtra("latitude", latitude), getIntent().getDoubleExtra("longitude", longitude));
            googleMap.addMarker(new MarkerOptions().position(current_location).title("Listing is is here").draggable(true));
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(current_location, 15));

        } else {
            LatLng current_location = new LatLng(latitude, longitude);
            googleMap.addMarker(new MarkerOptions().position(current_location).title("Your current location").draggable(true));
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(current_location, 15));
            googleMap.setOnPoiClickListener(new GoogleMap.OnPoiClickListener() {
                @Override
                public void onPoiClick(final PointOfInterest pointOfInterest) {
                    Snackbar snackbar = Snackbar.make(findViewById(R.id.map), "Do you want to use " + pointOfInterest.name + " as a delivery point?", Snackbar.LENGTH_INDEFINITE);
                    snackbar.setAction("YES", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent resultIntent = new Intent();
                            resultIntent.putExtra("location", pointOfInterest);
                            setResult(Activity.RESULT_OK, resultIntent);
                            finish();
                        }
                    });
                    snackbar.show();

                }
            });
        }
    }
}
