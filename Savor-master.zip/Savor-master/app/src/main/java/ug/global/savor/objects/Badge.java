package ug.global.savor.objects;

public class Badge {
    String name;
    boolean finished;

    public Badge(String name, boolean finished) {
        this.name = name;
        this.finished = finished;
    }

    public String getName() {
        return name;
    }

    public boolean isFinished() {
        return finished;
    }
}
