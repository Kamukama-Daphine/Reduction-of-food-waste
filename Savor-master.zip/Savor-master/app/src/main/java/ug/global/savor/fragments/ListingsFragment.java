package ug.global.savor.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

import ug.global.savor.R;
import ug.global.savor.adapters.FoodItemsAdapter;
import ug.global.savor.objects.ListingObject;

import static android.content.ContentValues.TAG;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ListingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ListingsFragment extends Fragment {

    public ListingsFragment() {
        // Required empty public constructor
    }

    public static ListingsFragment newInstance() {
        return new ListingsFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View root = inflater.inflate(R.layout.fragment_food, container, false);
        RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        final ArrayList<ListingObject> listingObjects = new ArrayList<>();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("/listings");
        final FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        final FoodItemsAdapter foodItemsAdapter = new FoodItemsAdapter(listingObjects, null, requireContext(), false, reference, false);
        final ChipGroup chipGroup = root.findViewById(R.id.chipGroup3);
        reference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                ListingObject value = dataSnapshot.getValue(ListingObject.class);
                if (!value.getFirebaseUser().equals(firebaseUser.getUid())) {
                    if (value != null) {
                        long now = Calendar.getInstance().getTimeInMillis();
                        long listingTime = value.getTimestamp();
                        long daysToList = value.getDaysToList();
                        int Days = (int) ((now - listingTime) / (1000 * 60 * 60 * 24));
                        if (Days <= daysToList) {
                            value.setKey(dataSnapshot.getKey());
                            listingObjects.add(value);

                            foodItemsAdapter.notifyDataSetChanged();
                        }
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chipGroup.setVisibility(View.VISIBLE);
                root.findViewById(R.id.progress).setVisibility(View.GONE);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        recyclerView.setAdapter(foodItemsAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 2, RecyclerView.VERTICAL, false));
        foodItemsAdapter.notifyDataSetChanged();
        chipGroup.setOnCheckedChangeListener(new ChipGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(ChipGroup group, int checkedId) {
                Log.i(TAG, "onCheckedChanged:" + checkedId);
                switch (checkedId) {
                    case R.id.allFoodChip:
                        Log.i(TAG, "onCheckedChanged: ");
                        foodItemsAdapter.getFilter().filter("all_food");
                        break;
                    case R.id.foodChip:
                        foodItemsAdapter.getFilter().filter("food");
                        break;
                    case R.id.drinksChip:
                        foodItemsAdapter.getFilter().filter("drink");
                        break;
                }
            }
        });
        return root;
    }
}
