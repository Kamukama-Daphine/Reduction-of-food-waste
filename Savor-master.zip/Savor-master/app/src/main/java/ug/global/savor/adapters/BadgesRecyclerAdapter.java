package ug.global.savor.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ug.global.savor.R;
import ug.global.savor.objects.Badge;

public class BadgesRecyclerAdapter extends RecyclerView.Adapter<BadgesRecyclerAdapter.ViewHolder> {
    Context context;
    ArrayList<Badge> badges;

    public BadgesRecyclerAdapter(Context context, ArrayList<Badge> badges) {
        this.context = context;
        this.badges = badges;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.badge_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.badgeName.setText(badges.get(position).getName());
        if (badges.get(position).isFinished()) {
            holder.lock.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return badges.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView badgeName;
        ImageView lock;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            lock = itemView.findViewById(R.id.lock);
            badgeName = itemView.findViewById(R.id.badgeName);
        }
    }
}
