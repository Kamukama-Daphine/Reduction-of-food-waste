package ug.global.savor;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

import ug.global.savor.adapters.FoodItemsAdapter;
import ug.global.savor.objects.ListingObject;

public class MyListingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_listings);
        Toolbar toolbar = findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        final ProgressBar progressBar = findViewById(R.id.progress);
        final ArrayList<ListingObject> listingObjects = new ArrayList<>();
        final FoodItemsAdapter foodItemsAdapter = new FoodItemsAdapter(listingObjects, null, this, true, FirebaseDatabase.getInstance().getReference("/listings"), false);
        recyclerView.setAdapter(foodItemsAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3, RecyclerView.VERTICAL, false));
        String firebaseUser = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
        Query reference = FirebaseDatabase.getInstance().getReference("/listings").orderByChild("firebaseUser").equalTo(firebaseUser);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                progressBar.setVisibility(View.GONE);
                if (dataSnapshot.getChildrenCount() == 0) {
                    Snackbar.make(findViewById(R.id.main), "You have not yet added any listings", BaseTransientBottomBar.LENGTH_INDEFINITE).setAction("ADD", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            finish();
                            startActivity(new Intent(MyListingsActivity.this, AddListingActivity.class));
                        }
                    }).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                progressBar.setVisibility(View.GONE);
            }
        });
        final ArrayList<String> keys = new ArrayList<>();
        reference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                ListingObject value = dataSnapshot.getValue(ListingObject.class);
                if (value != null) {
                    value.setKey(dataSnapshot.getKey());
                    listingObjects.add(value);
                    keys.add(dataSnapshot.getKey());
                    foodItemsAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}