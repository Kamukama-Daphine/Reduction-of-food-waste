package ug.global.savor.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.Objects;

import ug.global.savor.AddListingActivity;
import ug.global.savor.FoodDetailActivity;
import ug.global.savor.R;
import ug.global.savor.helpers.SearchFilter;
import ug.global.savor.objects.ListingObject;
import ug.global.savor.objects.UserObject;

public class FoodItemsAdapter extends RecyclerView.Adapter<FoodItemsAdapter.ViewHolder> implements Filterable {
    public static ListingObject activeObject;
    public ArrayList<ListingObject> listingObjects;
    public ArrayList<ListingObject> filteredList;
    private ArrayList<UserObject> userObjects;
    private Context context;
    private boolean isUserMode;
    private DatabaseReference reference;
    private SearchFilter filter;
    private boolean isPerson;

    public FoodItemsAdapter(@Nullable ArrayList<ListingObject> listingObjects, @Nullable ArrayList<UserObject> userObjects, Context context, boolean isUserMode, DatabaseReference reference,
                            boolean isPerson) {
        this.listingObjects = listingObjects;
        this.userObjects = userObjects;
        this.context = context;
        this.isUserMode = isUserMode;
        this.reference = reference;
        this.filteredList = listingObjects;
        this.isPerson = isPerson;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.food_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        ListingObject listingObject = null;
        try {
            listingObject = listingObjects.get(position);
            Glide.with(context).load(listingObject.getPhoto()).into(holder.imageView);
            ViewCompat.setTransitionName(holder.imageView, listingObject.getName());
            holder.textView.setText(listingObject.getName());
        } catch (Exception ignored) {}
        if (isPerson) {
            holder.textView.setText(userObjects.get(position).getName());
            Glide.with(context).load(userObjects.get(position).getPhoto()).into(holder.imageView);
        } else if (isUserMode) {
            final ListingObject finalListingObject = listingObject;
            holder.more.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PopupMenu popupMenu = new PopupMenu(context, holder.more);
                    popupMenu.getMenu().add("Remove");
                    popupMenu.getMenu().add("Edit");
                    popupMenu.show();
                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            if (item.getTitle().equals("Remove")) {
                                reference.child(finalListingObject.getKey()).removeValue();
                                notifyDataSetChanged();
                            } else {
                                activeObject = finalListingObject;
                                context.startActivity(new Intent(context, AddListingActivity.class).putExtra("edit_mode", true));
                            }
                            return true;
                        }
                    });
                }
            });
        } else {
            holder.more.setVisibility(View.GONE);
            final ListingObject finalListingObject1 = listingObject;
            holder.imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, FoodDetailActivity.class);
                    intent.putExtra("food_name", finalListingObject1.getName());
                    intent.putExtra("food_description", finalListingObject1.getDescription());
                    intent.putExtra("food_image", finalListingObject1.getPhoto());
                    intent.putExtra("transition_name", ViewCompat.getTransitionName(holder.imageView));
                    intent.putExtra("food_location", finalListingObject1.getPickupLocation());
                    intent.putExtra("food_key", finalListingObject1.getKey());
                    ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation((Activity) context, holder.imageView, Objects.requireNonNull(ViewCompat.getTransitionName(holder.imageView)));
                    context.startActivity(intent, optionsCompat.toBundle());
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return listingObjects == null ? userObjects.size() : listingObjects.size();
    }

    @Override
    public Filter getFilter() {
        return (filter == null) ? new SearchFilter(filteredList, this) : filter;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView, more;
        private TextView textView;
        private CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            imageView = itemView.findViewById(R.id.foodDesc);
            textView = itemView.findViewById(R.id.foodName);
            more = itemView.findViewById(R.id.more);
        }
    }
}
