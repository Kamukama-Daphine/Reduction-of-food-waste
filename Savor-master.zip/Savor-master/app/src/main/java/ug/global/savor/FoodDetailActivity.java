package ug.global.savor;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FoodDetailActivity extends AppCompatActivity {
    String food_location = "";
    String[] s = new String[0];
    private String key;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_detail_activity);
        supportPostponeEnterTransition();
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView descText = findViewById(R.id.description);
        ImageView imageView = findViewById(R.id.imageTitle);
        final TextView locationTxt = findViewById(R.id.location);
        Bundle extras = getIntent().getExtras();
        String name = "Deafult", desc = "Deafult", transition_name = "Default";
        String photo = "null";
        if (extras != null) {
            name = extras.getString("food_name");
            desc = extras.getString("food_description");
            photo = extras.getString("food_image");
            key = extras.getString("food_key");
            food_location = extras.getString("food_location");
        }

        if (food_location != null) {
            s = food_location.split("__");
        }
        descText.setText(desc);
        setSupportActionBar(toolbar);
        toolbar.setTitle(name);
        findViewById(R.id.mapButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FoodDetailActivity.this, MapsActivity.class).
                        putExtra("show_listing", true).
                        putExtra("latitiude", Double.parseDouble(s[0])).
                        putExtra("longitude", Double.parseDouble(s[1]))
                );
            }
        });
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(5 * 1000);
        LocationCallback locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                for (Location location : locationResult.getLocations()) {
                    Location food = new Location("");
                    food.setLatitude(Double.parseDouble(s[0]));
                    food.setLongitude(Double.parseDouble(s[1]));
                    float v = (food.distanceTo(location)) / 1000;
                    locationTxt.setText(String.format("Listing is %s km away", v));
                }
            }

        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        Glide.with(this).load(photo).into(imageView);
        imageView.setTransitionName(extras != null ? extras.getString("transition_name") : "null");
        supportStartPostponedEnterTransition();
        findViewById(R.id.saveBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(findViewById(R.id.mainView), "Listing marked as collected. Continue tp navigation?", BaseTransientBottomBar.LENGTH_INDEFINITE).setAction("START",
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("/listings");
                                reference.child(key).child("taken").setValue(true);
                                Uri gmmIntentUri = Uri.parse("google.navigation:q=" + Double.parseDouble(s[0]) + "," + Double.parseDouble(s[1]) + "");
                                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                                mapIntent.setPackage("com.google.android.apps.maps");
                                try {
                                    startActivity(mapIntent);
                                } catch (ActivityNotFoundException activityNotFoundException) {
                                    Snackbar.make(findViewById(R.id.mainView), "Navigation application missing. Please install and try again", BaseTransientBottomBar.LENGTH_INDEFINITE).
                                            setAction("INSTALL", new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.maps")));

                                                }
                                            }).show();
                                }
                            }
                        }).show();
            }
        });
    }
}
