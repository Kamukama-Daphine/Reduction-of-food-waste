package ug.global.savor;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Objects;

import ug.global.savor.adapters.ChatRecyclerAdapter;
import ug.global.savor.objects.Chat;

public class ChatActivity extends AppCompatActivity {

    public static DatabaseReference chatRef;
    private static ArrayList<Chat> chats;
    private static ArrayList<Chat> chats2;
    @SuppressLint("StaticFieldLeak")
    private static ChatRecyclerAdapter chatRecyclerAdapter;
    private static ChatRecyclerAdapter chatRecyclerAdapter2;
    String chatId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        final String person = getIntent().getStringExtra("person");
        final String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();


        chatRef = FirebaseDatabase.getInstance().getReference("/chats");
        final ProgressBar progressBar = findViewById(R.id.messages_progress_bar);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerView recyclerView2 = findViewById(R.id.recyclerView2);
        TextInputLayout textInputLayout = findViewById(R.id.textLayout);
        final TextInputEditText textInputEditText = findViewById(R.id.textMessage);
        textInputLayout.setEndIconOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = textInputEditText.getEditableText().toString().trim();
                if (message.length() > 3) {
                    Chat chat = new Chat(Calendar.getInstance().getTimeInMillis(), uid, person, message);
                    chatRef.child(Objects.requireNonNull(chatRef.push().getKey())).setValue(chat);
                    textInputEditText.setText("");
                }
            }
        });
        chats = new ArrayList<>();
        chats2 = new ArrayList<>();
        chatRecyclerAdapter = new ChatRecyclerAdapter(this, chats, uid);
        chatRecyclerAdapter2 = new ChatRecyclerAdapter(this, chats2, uid);
        recyclerView.setAdapter(chatRecyclerAdapter);
        recyclerView2.setAdapter(chatRecyclerAdapter2);
        chatRef.orderByChild("chatId").equalTo(person + uid).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Chat chat = dataSnapshot.getValue(Chat.class);
                chats.add(chat);
                chatRecyclerAdapter.notifyDataSetChanged();
                progressBar.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        chatRef.orderByChild("chatId").equalTo(uid + person).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Chat chat = dataSnapshot.getValue(Chat.class);
                chats2.add(chat);
                chatRecyclerAdapter2.notifyDataSetChanged();
                progressBar.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        recyclerView.scrollToPosition(chats.size() - 1);

    }


}