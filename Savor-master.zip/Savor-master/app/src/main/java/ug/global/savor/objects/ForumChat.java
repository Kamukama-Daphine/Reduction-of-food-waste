package ug.global.savor.objects;

public class ForumChat {
    private long date;
    private String sender;
    private String message;
    private String photo;

    public ForumChat() {
    }

    public ForumChat(long date, String sender, String message, String photo) {
        this.date = date;
        this.sender = sender;
        this.message = message;
        this.photo = photo;
    }

    public String getPhoto() {
        return photo;
    }

    public long getDate() {
        return date;
    }

    public String getSender() {
        return sender;
    }

    public String getMessage() {
        return message;
    }
}
