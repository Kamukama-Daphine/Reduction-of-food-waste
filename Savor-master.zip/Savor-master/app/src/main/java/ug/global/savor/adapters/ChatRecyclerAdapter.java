package ug.global.savor.adapters;


import android.content.Context;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ug.global.savor.R;
import ug.global.savor.objects.Chat;

public class ChatRecyclerAdapter extends RecyclerView.Adapter<ChatRecyclerAdapter.ViewHolder> {
    private final Context context;
    private final ArrayList<Chat> chats;
    private final String user;

    public ChatRecyclerAdapter(Context context, ArrayList<Chat> chats, String user) {
        this.context = context;
        this.chats = chats;
        this.user = user;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View root = LayoutInflater.from(context).inflate(R.layout.chat_item, parent, false);
        return new ViewHolder(root);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String timepast = DateUtils.getRelativeTimeSpanString(chats.get(position).getDate(), System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString();
        holder.mesage.setText(String.format("%s - %s", chats.get(position).getMessage(), timepast));
        if (chats.get(position).getFrom().equals(user)) {
            holder.sender.setText(R.string.you);
            holder.sender.setTextColor(context.getResources().getColor(R.color.colorAccent));
        } else {
            holder.sender.setText(chats.get(position).getFrom());
            holder.sender.setTextColor(context.getResources().getColor(R.color.colorPrimary));
        }

    }

    @Override
    public int getItemCount() {
        return chats.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView sender;
        private final TextView mesage;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            sender = itemView.findViewById(R.id.senderTxt);
            mesage = itemView.findViewById(R.id.messageTxt);
        }
    }
}
