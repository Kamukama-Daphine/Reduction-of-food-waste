package ug.global.savor.helpers;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import ug.global.savor.R;

public class Helpers {
    public static String getPrefs(Context context, String key) {
        return context.getSharedPreferences("settings", Context.MODE_PRIVATE).getString(key, "no_value");
    }

    public static void savePrefs(Context context, String key, String value) {
        context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putString(key, value).apply();
    }

    public void convertLocation(TextView textView, Context context, double lo, double la) {
        try {
            List<Address> addresses = new Geocoder(context, Locale.getDefault()).getFromLocation(la, lo, 1);
            String address = "" + addresses.get(0).getFeatureName() + " , " + addresses.get(0).getLocality();

            textView.setText(String.format("%s ", address));

        } catch (IOException e) {
            textView.setText(R.string.unable_to_parse);
        }
    }
}
