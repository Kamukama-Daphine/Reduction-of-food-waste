package ug.global.savor;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ug.global.savor.adapters.BadgesRecyclerAdapter;
import ug.global.savor.objects.Badge;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BadgesFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BadgesFragment extends Fragment {
    public BadgesFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BadgesFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static BadgesFragment newInstance(String param1, String param2) {
        return new BadgesFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_badges, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        ArrayList<Badge> badges = new ArrayList<>();
        BadgesRecyclerAdapter recyclerAdapter = new BadgesRecyclerAdapter(getContext(), badges);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        badges.add(new Badge("New Account", true));
        badges.add(new Badge("First Listing", true));
        badges.add(new Badge("First Order", false));
        badges.add(new Badge("Community Builder", false));
        badges.add(new Badge("Pay it forward", false));
        badges.add(new Badge("Wall of Fame", false));
        badges.add(new Badge("First 10 Listings", false));
        badges.add(new Badge("Cupboard Clear out", false));
        recyclerAdapter.notifyDataSetChanged();
    }
}