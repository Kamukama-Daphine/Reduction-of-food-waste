package ug.global.savor.objects;

public class Chat {
    private long date;
    private String from;
    private String to;
    private String message;
    private String chatId;

    public Chat(long date, String from, String to, String message) {
        this.date = date;
        this.from = from;
        this.to = to;
        this.message = message;
        this.chatId = to + from;
    }

    public Chat() {
    }

    public String getChatId() {
        return chatId;
    }

    public long getDate() {
        return date;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getMessage() {
        return message;
    }
}
