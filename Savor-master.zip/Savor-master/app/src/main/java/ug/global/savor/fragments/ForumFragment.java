package ug.global.savor.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Objects;

import ug.global.savor.MainActivity;
import ug.global.savor.R;
import ug.global.savor.adapters.ForumChatAdapter;
import ug.global.savor.objects.ForumChat;


public class ForumFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    public ForumFragment() {
        // Required empty public constructor
    }

    public static ForumFragment newInstance(String param1, String param2) {
        ForumFragment fragment = new ForumFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_forum, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View root, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(root, savedInstanceState);
        final RecyclerView recyclerView = root.findViewById(R.id.forumRecycler);
        final ProgressBar progressBar = root.findViewById(R.id.progressBarForum);
        final TextInputLayout textInputLayout = root.findViewById(R.id.textLayout);
        final TextInputEditText message = root.findViewById(R.id.textMessage);
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("/forum");
        final ArrayList<ForumChat> forumChats = new ArrayList<>();
        final ForumChatAdapter adapter = new ForumChatAdapter(forumChats, requireContext());
        reference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                ForumChat forumChat = dataSnapshot.getValue(ForumChat.class);
                forumChats.add(forumChat);
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        recyclerView.setAdapter(adapter);
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false);
        linearLayoutManager.setReverseLayout(true);
        textInputLayout.setEndIconOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageTxt = message.getEditableText().toString();
                textInputLayout.setVisibility(View.GONE);
                MainActivity.fab.show();
                progressBar.setVisibility(View.VISIBLE);
                message.clearFocus();
                FirebaseUser firebaseUser = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser());
                String sender = firebaseUser.getDisplayName() == null ? firebaseUser.getPhoneNumber() : firebaseUser.getDisplayName();
                String photo = firebaseUser.getPhotoUrl() == null ? "No photo" : firebaseUser.getPhotoUrl().toString();
                ForumChat forumChat = new ForumChat(Calendar.getInstance().getTimeInMillis(), sender, messageTxt, photo);
                reference.child(Objects.requireNonNull(reference.push().getKey())).setValue(forumChat).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        progressBar.setVisibility(View.GONE);
                    }
                });
            }
        });
        recyclerView.setLayoutManager(linearLayoutManager);
        MainActivity.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.fab.hide();
                textInputLayout.setVisibility(View.VISIBLE);
            }
        });

    }
}
