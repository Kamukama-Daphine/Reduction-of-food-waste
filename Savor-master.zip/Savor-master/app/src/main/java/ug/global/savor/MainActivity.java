package ug.global.savor;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import ug.global.savor.fragments.ForumFragment;
import ug.global.savor.fragments.HomeFragment;
import ug.global.savor.fragments.ListingsFragment;
import ug.global.savor.fragments.MessagesFragment;
import ug.global.savor.helpers.Helpers;
import ug.global.savor.objects.ListingObject;

public class MainActivity extends AppCompatActivity {
    private static final int ADD_LISTING_REQUEST = 123;
    private static final int PERMISSION_REQUEST_EXTERNAL_STORAGE = 111;
    private static final String CHANNEL_ID = "channel";
    private static final int NOTIFICATION_REQ_CODE = 200;
    private static final int NOTIFICATION_ID = 1;
    public static FloatingActionButton fab;
    @SuppressLint("StaticFieldLeak")
    public static ProgressBar progressBar;
    ActionBarDrawerToggle toggle;
    private Toolbar actionBar;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return toggle.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_EXTERNAL_STORAGE);
        if (Helpers.getPrefs(this, "registered").equals("no_value")) {
            finish();
            startActivity(new Intent(this, GoogleSignInActivity.class));
        } else if (Helpers.getPrefs(this, "sign_up").equals("no_value")) {
            finish();
            startActivity(new Intent(this, SignUpActivity.class));
        } else {
            setContentView(R.layout.activity_main);
            actionBar = findViewById(R.id.toolbar);
            if (actionBar != null) {
                actionBar.setTitle(getResources().getString(R.string.home));
            }
            if (actionBar != null) {
                actionBar.setTitle(getResources().getString(R.string.home));
            }
            setSupportActionBar(actionBar);
            Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            final DrawerLayout drawer = findViewById(R.id.drawerLayout);
            toggle = new ActionBarDrawerToggle(this, drawer, actionBar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.setDrawerIndicatorEnabled(true);
            toggle.syncState();
            progressBar = findViewById(R.id.progress);
            setSupportActionBar(actionBar);
            loadFragment(HomeFragment.newInstance("", ""));
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            NavigationView navigationView = findViewById(R.id.navigationView);
            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    FragmentManager supportFragmentManager = getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = supportFragmentManager.beginTransaction();
                    int itemId = item.getItemId();
                    if (itemId == R.id.nav_home) {
                        fragmentTransaction.replace(R.id.frameLayout, new HomeFragment());
                    } else if (itemId == R.id.nav_account) {
                        fragmentTransaction.replace(R.id.frameLayout, new AccountFragment());
                    } else if (itemId == R.id.nav_badges) {
                        fragmentTransaction.replace(R.id.frameLayout, new BadgesFragment());
                    }
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                    drawer.closeDrawers();
                    return false;
                }
            });

            FirebaseDatabase.getInstance().getReference("/listings").addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    ListingObject value = dataSnapshot.getValue(ListingObject.class);
                    if (value != null) {
                        String username = FirebaseAuth.getInstance().getCurrentUser().getDisplayName();
                        sendNotification(username == null ? "there" : username);

                    }

                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            View navHeader = navigationView.getHeaderView(0);
            CircleImageView circleImageView = navHeader.findViewById(R.id.circleImage);
            TextView username = navHeader.findViewById(R.id.userName);
            if (currentUser != null) {
                Glide.with(this).load(currentUser.getPhotoUrl()).into(circleImageView);
            }
            username.setText(String.format("%s", currentUser.getPhoneNumber()));
            fab = findViewById(R.id.addListing);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    startActivityForResult(new Intent(MainActivity.this, AddListingActivity.class), ADD_LISTING_REQUEST);
                }
            });
            BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment fragment;
                    int itemId = item.getItemId();
                    if (itemId == R.id.home) {
                        actionBar.setTitle(getResources().getString(R.string.home));
                        fragment = HomeFragment.newInstance("", "");
                        fab.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startActivityForResult(new Intent(MainActivity.this, AddListingActivity.class), ADD_LISTING_REQUEST);
                            }
                        });
                    } else if (itemId == R.id.food) {
                        fab.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startActivityForResult(new Intent(MainActivity.this, AddListingActivity.class), ADD_LISTING_REQUEST);
                            }
                        });
                        actionBar.setTitle(getResources().getString(R.string.food));
                        fragment = ListingsFragment.newInstance();
                    } else if (itemId == R.id.forum) {
                        actionBar.setTitle(getResources().getString(R.string.forum));

                        fragment = ForumFragment.newInstance("", "");
                    } else if (itemId == R.id.chats) {
                        actionBar.setTitle(getResources().getString(R.string.message));
                        fragment = MessagesFragment.newInstance("", "");
                    } else {
                        fragment = HomeFragment.newInstance("", "");
                    }
                    loadFragment(fragment);
                    return true;
                }
            });
        }
    }


    void sendNotification(String username) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, NOTIFICATION_REQ_CODE, intent, 0);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("New Listing!")
                .setContentText("Hello," + username + ", A new listing has been added. Check it out")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    private void loadFragment(Fragment newInstance) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frameLayout, newInstance);
        transaction.addToBackStack(null);
        transaction.commit();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_LISTING_REQUEST) {
            startActivity(new Intent(MainActivity.this, MyListingsActivity.class));
        }
    }
}
