package ug.global.savor.objects;

public class ListingObject {
    String name;
    String photo;
    boolean food;
    String description;
    long daysToList;
    String firebaseUser;
    boolean taken;
    private long timestamp;
    private String key;
    private String pickupTime;
    private String pickupLocation;


    public ListingObject() {
    }

    public ListingObject(String name, String photo, boolean food, String description, long daysToList, String firebaseUser, boolean taken, long timestamp, String pickupTime, String pickupLocation) {
        this.name = name;
        this.photo = photo;
        this.food = food;
        this.description = description;
        this.daysToList = daysToList;
        this.firebaseUser = firebaseUser;
        this.taken = taken;
        this.timestamp = timestamp;
        this.pickupTime = pickupTime;
        this.pickupLocation = pickupLocation;
    }

    public ListingObject(String name) {
        this.name = name;
    }

    public String getFirebaseUser() {
        return firebaseUser;
    }

    public void setFirebaseUser(String firebaseUser) {
        this.firebaseUser = firebaseUser;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(String pickupTime) {
        this.pickupTime = pickupTime;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public boolean isFood() {
        return food;
    }

    public void setFood(boolean food) {
        this.food = food;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getDaysToList() {
        return daysToList;
    }

    public void setDaysToList(long daysToList) {
        this.daysToList = daysToList;
    }

    public boolean isTaken() {
        return taken;
    }

    public void setTaken(boolean taken) {
        this.taken = taken;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
