package ug.global.savor;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Objects;

import ug.global.savor.helpers.Helpers;
import ug.global.savor.objects.UserObject;

public class SignUpActivity extends AppCompatActivity {
    private ArrayList<OnBoardingItem> onBoardingItems = new ArrayList<>();
    private ArrayList<String> chip_choices = new ArrayList<>();
    private ChipGroup chipGroup;
    private boolean isgiver = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_screen);
        final ViewPager viewPager = findViewById(R.id.viewPager);
        LinearLayout pagerIndicator = findViewById(R.id.linear);
        loadData();
        OnBoardingAdapter onBoardingAdapter = new OnBoardingAdapter(this, onBoardingItems);
        viewPager.setAdapter(onBoardingAdapter);

        final ImageView[] dots = new ImageView[onBoardingAdapter.getCount()];
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(getDrawable(R.drawable.carousel_indicator));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(6, 0, 0, 6);
            pagerIndicator.addView(dots[i], params);
        }
        final String[] chip_items = new String[]{"CupBoard Clear Out", "Don't Like it", "Post Due Date", "Bought Too Many", "Baked Too Much", "Extras from my garden", "Unwanted Gifts", "Got a journey"};
        dots[0].setImageDrawable(getDrawable(R.drawable.carousel_indicator_active));
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                Log.i("ofmgdfg", position + "");
                for (ImageView dot : dots) {
                    dot.setImageDrawable(getDrawable(R.drawable.carousel_indicator));
                }
                dots[position].setImageDrawable(getDrawable(R.drawable.carousel_indicator_active));
                switch (position) {
                    case 0:
                        findViewById(R.id.startButton).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                viewPager.setCurrentItem(1, true);
                            }
                        });
                        break;
                    case 1:
                        chipGroup = findViewById(R.id.chipGroup_giving);
                        chipGroup.removeAllViews();
                        for (final String chip_item : chip_items) {
                            Chip chip = (Chip) getLayoutInflater().inflate(R.layout.chip_item, chipGroup, false);
                            chip.setText(chip_item);
                            if (chip_choices.contains(chip_item)) {
                                chip.setChecked(true);
                            }
                            chipGroup.addView(chip);
                            chip.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                @Override
                                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                    if (isChecked) {
                                        chip_choices.add(chip_item);
                                    } else {
                                        chip_choices.remove(chip_item);
                                    }
                                }
                            });
                        }
                        break;
                    case 3:
                        Button button = findViewById(R.id.button_three);
                        ((ChipGroup) findViewById(R.id.chipGroup2)).setOnCheckedChangeListener(new ChipGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(ChipGroup group, int checkedId) {
                                isgiver = checkedId == R.id.giver;
                            }
                        });
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                final ProgressDialog progressDialog = new ProgressDialog(SignUpActivity.this);
                                progressDialog.setCancelable(false);
                                progressDialog.setMessage("Please wait while we save your data");
                                progressDialog.show();
                                FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                                String name = currentUser.getDisplayName();
                                String photo = String.valueOf(currentUser.getPhotoUrl());
                                UserObject userObject = new UserObject(currentUser.getUid(), chip_choices, isgiver, name, photo);
                                Log.i("srfsfsf", userObject.toString());
                                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("/users");
                                String key = Objects.requireNonNull(currentUser.getUid());
                                Log.i("lksf", userObject + key);
                                reference.child(key).setValue(userObject).addOnCompleteListener(
                                        new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                Helpers.savePrefs(SignUpActivity.this, "sign_up", "done");
                                                finish();
                                                startActivity(new Intent(SignUpActivity.this, MainActivity.class));
                                            }
                                        }
                                );
                            }
                        });
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    public void loadData() {
        int[] views = {R.layout.sign_up_zero, R.layout.sign_up_one, R.layout.sign_up_two, R.layout.sign_up_three};
        for (int view : views) {
            onBoardingItems.add(new OnBoardingItem(view));
        }
    }

    static class OnBoardingItem {
        private int view;

        OnBoardingItem(int view) {
            this.view = view;
        }

        public int getView() {
            return view;
        }
    }

    static class OnBoardingAdapter extends PagerAdapter {
        private Context context;
        private ArrayList<OnBoardingItem> onBoardingItems;

        OnBoardingAdapter(Context context, ArrayList<OnBoardingItem> onBoardingItems) {
            this.context = context;
            this.onBoardingItems = onBoardingItems;
        }

        @Override
        public int getCount() {
            return onBoardingItems.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            View itemView = LayoutInflater.from(context).inflate(onBoardingItems.get(position).getView(), container, false);
            container.addView(itemView);
            return itemView;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }
    }

}